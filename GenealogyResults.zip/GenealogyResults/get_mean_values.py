import os

results_type = ["clique", "general", "kcolor"]

results_files = {}

for res in results_type:
    results_files[res] = os.listdir(f"./{res}")

for res in results_type:
    print("Getting results for ", res)
    for file in results_files[res]:
        with open(f"./{res}/{file}") as f:
            lines = f.readlines()
        print(f"For {file}: {round(float(lines[-2].split()[1][:-1]), 3)}, {round(float(lines[-1].split()[2][:-1]), 3)}")
